//CoordinateConstants.DISABLING_CHUNK_POS*16 as a block position for rendering
#define DISABLING_BLOCK_POS 60322112
#define SCALE 3

uniform ivec2 dimensionBounds;

float curve_dimension(vec2 pos) {
    vec2 modPos = pos;
    //Disabled dimension curvature on x-axis
    if(dimensionBounds.x == DISABLING_BLOCK_POS)
    modPos.x = 0.0;

    //Disabled dimension curvature on z-axis
    if(dimensionBounds.y == DISABLING_BLOCK_POS)
    modPos.y = 0.0;

    vec2 scaledSize = dimensionBounds * SCALE;

    return ((modPos.x * modPos.x)/(scaledSize.x) + (modPos.y * modPos.y)/(scaledSize.y));
}