#version 120
uniform mat4 gbufferModelView, gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;

out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;

#include "/lib/curvature.glsl"

void main() {
    vec4 position = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
    position.y -= curve_dimension(position.xz);
    gl_Position = gl_ProjectionMatrix * gbufferModelView * position;

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor = gl_Color;
}